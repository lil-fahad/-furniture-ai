from fastapi import FastAPI
app = FastAPI(title='AI Engine PRO')